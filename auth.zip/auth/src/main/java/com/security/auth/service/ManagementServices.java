package com.security.auth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.security.auth.model.Management;
import com.security.auth.repository.ManagementRepository;

@Service
public class ManagementServices {

	@Autowired
	private ManagementRepository repo;
	
	public List<Management> listAll(){
		return repo.findAll();
	}
	
	public void save(Management management) {
		repo.save(management);
	}
	
	public Management get(Long id) {
		return repo.findById(id).get();
	}
	
	public void delete(Long id) {
		repo.deleteById(id);
	}
	
	
}
