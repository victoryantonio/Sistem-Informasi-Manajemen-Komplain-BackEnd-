package com.security.auth.repository;

import com.security.auth.model.LaporanKerusakan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LaporanKerusakanRepository extends JpaRepository<LaporanKerusakan, String> {
    
}
