package com.security.auth.service;

import java.util.List;

import com.security.auth.model.LaporanKerusakan;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public interface LaporanKerusakanService {
    @Autowired
    List<LaporanKerusakan> findAllPeople();
    LaporanKerusakan findById(String BKT);
    LaporanKerusakan insert(LaporanKerusakan laporan);
    boolean delete(String BKT);
    boolean update(LaporanKerusakan laporan);
}
