package com.security.auth.controller;

import com.security.auth.model.LaporanKerusakan;
import com.security.auth.repository.LaporanKerusakanRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/pelaporan")
public class LaporanKerusakanController {
    @Autowired
    LaporanKerusakanRepository LaporanKerusakanRepository;

    @GetMapping("/allLaporan")
    public List<LaporanKerusakan> getAllLaporan() {
        List<LaporanKerusakan> allLaporanList = LaporanKerusakanRepository.findAll();
        return allLaporanList;
    }
    
    @GetMapping("/laporan/{bkt}")
    public LaporanKerusakan getLaporanbyBKT(@PathVariable(value = "bkt") String bkt)
	{
		LaporanKerusakan laporanKerusakan = LaporanKerusakanRepository.findById(bkt).get();
		return laporanKerusakan;	
	}

    @PostMapping("/createLaporan")
    @ResponseBody
    public LaporanKerusakan createLaporan(@RequestBody LaporanKerusakan laporan) {
        LaporanKerusakan savedLaporan = LaporanKerusakanRepository.save(laporan);
    	return savedLaporan;
    }

    @PutMapping("/updateLaporan/{bkt}")
    public ResponseEntity<LaporanKerusakan> updateLaporan(@PathVariable(value = "bkt") String bkt,
        @RequestBody LaporanKerusakan laporanDetails) {
        LaporanKerusakan laporan = LaporanKerusakanRepository.findById(bkt).get();

        laporan.setBKT(laporanDetails.getBKT());
        laporan.setTglInput(laporanDetails.getTglInput());
        laporan.setJaringan(laporanDetails.isJaringan());
        laporan.setSoftware(laporanDetails.isSoftware());
        laporan.setHardware(laporanDetails.isHardware());
        laporan.setPelapor(laporanDetails.getPelapor());
        laporan.setKetPelapor(laporanDetails.getKetPelapor());
        laporan.setTeknisi(laporanDetails.getTeknisi());
        laporan.setTglPenanganan(laporanDetails.getTglPenanganan());
        laporan.setKetTeknisi(laporanDetails.getKetTeknisi());
        laporan.setFinish(laporanDetails.isFinish());
        final LaporanKerusakan updatedLaporan = LaporanKerusakanRepository.save(laporan);
        return ResponseEntity.ok(updatedLaporan);
    }
}
