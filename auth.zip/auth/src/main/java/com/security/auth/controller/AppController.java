package com.security.auth.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.security.auth.model.Management;
import com.security.auth.service.ManagementServices;

@Controller
public class AppController {

	@Autowired
	ManagementServices service;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		List<Management> listManagement = service.listAll();
		model.addAttribute("listManagement", listManagement);
		return "index";
	}
	
	@RequestMapping("/new")
	public String newManagementPage(Model model) {
		Management management=new Management();
		model.addAttribute(management);
		return "new_management";
	}
	
	@RequestMapping(value = "/save", method =RequestMethod.POST)
	public String saveManagement(@ModelAttribute("management") Management management ) {
		service.save(management);
		return "redirect:/";
	}
	@RequestMapping("/edit/{mid}")
	public ModelAndView showEditStudentPage(@PathVariable (name="mid") Long mid) {
		ModelAndView mav=new ModelAndView("edit_management");
		Management management=service.get(mid);
		mav.addObject("management", management);
		return mav;
	}
	
	@RequestMapping("/delete/{mid}")
	public String deleteManagementPage(@PathVariable (name="mid") Long mid) {
		service.delete(mid);
		return "redirect:/";
	}
	
}

