package com.security.auth.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.lang.Integer;

@Entity
@Table(name = "mLaporanKerusakan")
public class LaporanKerusakan implements Serializable{
    @Id
    @Column(name = "BKT", unique = true, nullable = false, length = 15)
    private String BKT;

    @CreationTimestamp
    @Column(name = "tglInput", updatable = false)
    private Timestamp tglInput;

    @Column(name = "isJaringan")
    private boolean isJaringan;

    @Column(name = "isSoftware")
	private boolean isSoftware;
    
    @Column(name = "isHardware")
	private boolean isHardware;

    @Column(name = "pelapor")
    private Integer pelapor;

    @Column(name = "ketPelapor", length = 50)
    private String ketPelapor;

    @UpdateTimestamp
    @Column(name = "tglPenanganan")
    private Timestamp tglPenanganan;

    @Column(name = "teknisi")
    private Integer teknisi;
    
    @Column(name = "ketTeknisi", length=50)
    private String ketTeknisi;  

    @Column(name = "isFinish")
	private boolean isFinish;

    public LaporanKerusakan() {

    }

    public LaporanKerusakan(String bKT, Timestamp tglInput, boolean isJaringan, boolean isSoftware, boolean isHardware,
            Integer pelapor, String ketPelapor, Timestamp tglPenanganan, Integer teknisi, String ketTeknisi,
            boolean isFinish) {
        BKT = bKT;
        this.tglInput = tglInput;
        this.isJaringan = isJaringan;
        this.isSoftware = isSoftware;
        this.isHardware = isHardware;
        this.pelapor = pelapor;
        this.ketPelapor = ketPelapor;
        this.tglPenanganan = tglPenanganan;
        this.teknisi = teknisi;
        this.ketTeknisi = ketTeknisi;
        this.isFinish = isFinish;
    }

    public String getBKT() {
        return BKT;
    }

    public void setBKT(String bKT) {
        BKT = bKT;
    }

    public Timestamp getTglInput() {
        return tglInput;
    }

    public void setTglInput(Timestamp tglInput) {
        this.tglInput = tglInput;
    }

    public boolean isJaringan() {
        return isJaringan;
    }

    public void setJaringan(boolean isJaringan) {
        this.isJaringan = isJaringan;
    }

    public boolean isSoftware() {
        return isSoftware;
    }

    public void setSoftware(boolean isSoftware) {
        this.isSoftware = isSoftware;
    }

    public boolean isHardware() {
        return isHardware;
    }

    public void setHardware(boolean isHardware) {
        this.isHardware = isHardware;
    }

    public Integer getPelapor() {
        return pelapor;
    }

    public void setPelapor(Integer pelapor) {
        this.pelapor = pelapor;
    }

    public String getKetPelapor() {
        return ketPelapor;
    }

    public void setKetPelapor(String ketPelapor) {
        this.ketPelapor = ketPelapor;
    }

    public Timestamp getTglPenanganan() {
        return tglPenanganan;
    }

    public void setTglPenanganan(Timestamp tglPenanganan) {
        this.tglPenanganan = tglPenanganan;
    }

    public Integer getTeknisi() {
        return teknisi;
    }

    public void setTeknisi(Integer teknisi) {
        this.teknisi = teknisi;
    }

    public String getKetTeknisi() {
        return ketTeknisi;
    }

    public void setKetTeknisi(String ketTeknisi) {
        this.ketTeknisi = ketTeknisi;
    }

    public boolean isFinish() {
        return isFinish;
    }

    public void setFinish(boolean isFinish) {
        this.isFinish = isFinish;
    }

    @Override
    public String toString() {
        return "Laporan Kerusakan [BKT: " + BKT + 
               "Tanggal Input: " + tglInput + 
               "Kerusakan Jaringan: " + isJaringan + 
               "Kerusakan Software: " + isSoftware + 
               "Kerusakan Hardware: " + isHardware + 
               "Pelapor: " + pelapor + 
               "Keterangan Pelapor: " + ketPelapor + 
               "Tanggal Penanganan: " + tglPenanganan + 
               "Teknisi: " + teknisi + 
               "Keterangan Teknisi: " + ketTeknisi + 
               "Terselesaikan: " + isFinish + "]";
    }
}
